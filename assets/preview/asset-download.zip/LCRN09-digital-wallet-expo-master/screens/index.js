import Home from "./Home"
import Scan from "./Scan"
import SignUp from "./SignUp"

export {
    Home,
    Scan,
    SignUp
};
